﻿======================================================
  SOULS GAME DEATH COUNTER - GLOBAL HOTKEY COMPANION
  Website: https://soulgamedc-rosy.vercel.app
======================================================

QUICK START:
1. Double-click 'RunHotkeys.bat' (or 'DeathCounterHotkeys.exe').
2. If Windows Defender SmartScreen appears:
   Click 'More info' -> Click 'Run anyway'.
3. The app connects automatically to:
   https://soulgamedc-rosy.vercel.app

DEFAULT KEYS (Global - works in fullscreen games):
- [F8]  : +1 Death
- [F7]  : Undo Death (-1)
- [F9]  : +1 Boss Slain
- [F10] : Undo Boss Slain (-1)