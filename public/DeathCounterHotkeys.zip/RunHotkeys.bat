@echo off
title Souls Death Counter Hotkeys
powershell -NoProfile -ExecutionPolicy Bypass -Command "Unblock-File -Path '%~dp0DeathCounterHotkeys.exe' -ErrorAction SilentlyContinue; Start-Process '%~dp0DeathCounterHotkeys.exe'"
exit
