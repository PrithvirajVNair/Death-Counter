@echo off
start "" "%~dp0DeathCounterHotkeys.exe"

