@echo off
title Souls Death Counter Hotkeys
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%~dp0*' | Unblock-File -ErrorAction SilentlyContinue"
start "" "%~dp0DeathCounterHotkeys.exe"

